package com.example.community.utils;

import lombok.Data;

@Data
public class ObjectItem {
    private String objectName;
    private Long size;
}