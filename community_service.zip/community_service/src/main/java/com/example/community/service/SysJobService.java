package com.example.community.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.community.entity.SysJob;

/**
 * 定时任务调度表(SysJob)表服务接口
 *
 * @author makejava
 * @since 2023-09-14 09:53:02
 */
public interface SysJobService extends IService<SysJob> {

}

