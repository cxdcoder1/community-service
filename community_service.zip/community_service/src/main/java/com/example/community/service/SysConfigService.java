package com.example.community.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.community.entity.SysConfig;

/**
 * 参数配置表(SysConfig)表服务接口
 *
 * @author makejava
 * @since 2023-09-14 09:53:01
 */
public interface SysConfigService extends IService<SysConfig> {

}

