package com.example.community.entity;

import lombok.Data;

@Data
public class ValueLabel {
    String value;
    String label;
}
