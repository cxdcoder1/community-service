package com.example.community.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.community.entity.SysJobLog;

/**
 * 定时任务调度日志表(SysJobLog)表服务接口
 *
 * @author makejava
 * @since 2023-09-14 09:53:02
 */
public interface SysJobLogService extends IService<SysJobLog> {

}

