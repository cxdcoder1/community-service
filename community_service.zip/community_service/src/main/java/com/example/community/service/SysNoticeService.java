package com.example.community.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.community.entity.SysNotice;

/**
 * 通知公告表(SysNotice)表服务接口
 *
 * @author makejava
 * @since 2023-09-14 09:53:02
 */
public interface SysNoticeService extends IService<SysNotice> {

}

