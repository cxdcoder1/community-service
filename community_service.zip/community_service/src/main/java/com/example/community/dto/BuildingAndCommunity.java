package com.example.community.dto;

public class BuildingAndCommunity {



}
