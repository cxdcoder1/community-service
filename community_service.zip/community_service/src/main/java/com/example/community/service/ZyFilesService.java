package com.example.community.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.community.entity.ZyFiles;

/**
 * 文件管理(ZyFiles)表服务接口
 *
 * @author makejava
 * @since 2023-09-14 09:53:03
 */
public interface ZyFilesService extends IService<ZyFiles> {

}

